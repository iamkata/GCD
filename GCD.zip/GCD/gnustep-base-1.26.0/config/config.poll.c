#include <poll.h>

#ifdef _POLL_EMUL_H_
int emulating_poll;
#endif
